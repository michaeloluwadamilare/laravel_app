 
<?php $__env->startSection('content'); ?>

<form action="/poll_store" method="POST">
    <div class="row">
        <h4>LGA RESULT CHECKER</h4>
        <?php echo e(csrf_field()); ?>

        <div class="col-md-3">
            <label>Polling Unit</label>
            <input type="text" name="polling_unit" class="form-control">
        </div>
        <div class="col-md-3">
            <label>Polling Unit Description</label>
            <input type="text" name="polling_desc" class="form-control">
        </div>
        <div class="col-md-3">
        <label>Ward</label>
            <select id="my-select" class="form-control" name="ward">
            <option value="">--Select Ward--</option>
            <?php $__currentLoopData = $wards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option value="<?php echo e($ward->uniqueid); ?>"> <?php echo e($ward->ward_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            
        </div>
        <div class="col-md-3">
        <label>LGA</label>
            <select id="my-select" class="form-control" name="lga">
            <option value="">--Select LGA--</option>
            <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option value="<?php echo e($lga->lga_id); ?>"> <?php echo e($lga->lga_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            
        </div>
        

    </div>
    
    
        <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

        <div class="row">
        <div class="col-md-4">
            <input type="hidden" name="party[]" value="<?php echo e($party->id); ?>">
            <input type="hidden" name="party_abb[]" value="<?php echo e($party->partyname); ?>">
            <p><strong> <?php echo e($party->partyname); ?> </strong></p>
        </div>
        <div class="col-md-4">
            <input type="number" placeholder="Enter party score" name="partyscore[]" class="form-control">
        </div>
        </div><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    
    <div class="row">
    <div class="col-md-12">
            <center> <button type="submit" class="btn btn-primary">Submit</button></center>
        </div>
        </div>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/firstlincoln/myproject/resources/views/pollsave.blade.php ENDPATH**/ ?>