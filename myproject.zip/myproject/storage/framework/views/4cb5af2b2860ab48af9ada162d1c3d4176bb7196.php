 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <h4><?php echo e(Str::upper($pu_result[0]->polling_unit_name)); ?> POLLING UNITS RESULT</h4>
        <table class="table table-stripped table-bordered">
            <tr>
                <th>Party</th>
                <th>Score</th>
            </tr>
            <?php ($total = 0); ?>
        <?php $__currentLoopData = $pu_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($result->party_abbreviation); ?></td>
            <td><?php echo e($result->party_score); ?></td>
        </tr>
        <?php ($total += $result->party_score); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><b>Total</b></th>
                <th><b><?php echo e($total); ?></b></th>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/firstlincoln/myproject/resources/views/polling_units_result.blade.php ENDPATH**/ ?>