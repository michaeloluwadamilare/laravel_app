 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <h4>LGA RESULT CHECKER</h4>
        <form action="/lga_result" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="col-md-4">
            <select class="form-control" name="lga">
            <option value="">--Select LGA--</option>
            <?php $__currentLoopData = $lgas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <option value="<?php echo e($lga->lga_id); ?>"> <?php echo e($lga->lga_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br>
            
        </div>
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary">Check</button>
        </div>
</form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/firstlincoln/myproject/resources/views/lga.blade.php ENDPATH**/ ?>