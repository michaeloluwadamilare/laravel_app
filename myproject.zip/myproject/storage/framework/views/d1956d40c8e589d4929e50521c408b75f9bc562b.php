 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <h4>POLLING UNITS</h4>
        <ul>
        <?php $__currentLoopData = $polling_units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polling_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($polling_unit->polling_unit_name): ?>
        <li><a href="<?php echo e(url('polling_units_result/'. $polling_unit->uniqueid)); ?>"> <?php echo e($polling_unit->polling_unit_name); ?> </a></li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/firstlincoln/myproject/resources/views/polling_units.blade.php ENDPATH**/ ?>