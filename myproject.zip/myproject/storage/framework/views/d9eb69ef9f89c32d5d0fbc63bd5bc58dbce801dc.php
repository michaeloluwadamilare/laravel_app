 
<?php $__env->startSection('content'); ?>
<?php if($lga_result): ?>
    <div class="row">
        <h4><?php echo e(Str::upper($lga_result[0]->lga_name)); ?> LGA  RESULT</h4>
        <table class="table table-stripped table-bordered">
            
        <?php ($total = 0); ?>
        <?php $__currentLoopData = $lga_result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php ($total += $result->party_score); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><b>Total Result</b></th>
                <th><b><?php echo e($total); ?></b></th>
            </tr>
        </table>
    </div>
<?php else: ?><p>No data available. </p>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/firstlincoln/myproject/resources/views/lga_result.blade.php ENDPATH**/ ?>